const sourceFiles = [
	'src/devlib2.xml',
	'src/common.xml',
	'src/startup.xml',
	'src/lov.xml',

	'src/map/prototypes.xml',
	'src/map/objects.xml',
	'src/map/events.xml',
	'src/map/actions.xml',
	'src/map/structure.xml'
];

const jsSources = [
	'../dev/js/common.js'
];

// const cssSources = [
// 	'../dev/css/tour.css'
// ];