function getKRPano() {
  window.krpano = document.getElementById('krpanoSWFObject');
}